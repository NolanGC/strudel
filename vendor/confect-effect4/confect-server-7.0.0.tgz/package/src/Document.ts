import { Effect, Function, pipe, Schema } from "effect";
import type { ReadonlyRecord } from "effect/Record";
import * as SystemFields from "@confect/core/SystemFields";
import type * as DataModel from "./DataModel";
import type { ReadonlyValue } from "./SchemaToValidator";
import type * as TableInfo from "./TableInfo";

export type WithoutSystemFields<Doc> = Omit<Doc, "_creationTime" | "_id">;

export type Any = any;
export type AnyEncoded = ReadonlyRecord<string, ReadonlyValue>;

export const decode = Function.dual<
  <
    DataModel_ extends DataModel.AnyWithProps,
    TableName extends DataModel.TableNames<DataModel_>,
  >(
    tableName: TableName,
    tableSchema: TableInfo.TableSchema<
      DataModel.TableInfoWithName_<DataModel_, TableName>
    >,
  ) => (
    self: DataModel.TableInfoWithName_<DataModel_, TableName>["convexDocument"],
  ) => Effect.Effect<
    DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
    DocumentDecodeError
  >,
  <
    DataModel_ extends DataModel.AnyWithProps,
    TableName extends DataModel.TableNames<DataModel_>,
  >(
    self: DataModel.TableInfoWithName_<DataModel_, TableName>["convexDocument"],
    tableName: TableName,
    tableSchema: TableInfo.TableSchema<
      DataModel.TableInfoWithName_<DataModel_, TableName>
    >,
  ) => Effect.Effect<
    DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
    DocumentDecodeError
  >
>(
  3,
  <
    DataModel_ extends DataModel.AnyWithProps,
    TableName extends DataModel.TableNames<DataModel_>,
  >(
    self: DataModel.TableInfoWithName_<DataModel_, TableName>["convexDocument"],
    tableName: TableName,
    tableSchema: TableInfo.TableSchema<
      DataModel.TableInfoWithName_<DataModel_, TableName>
    >,
  ): Effect.Effect<
    DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
    DocumentDecodeError
  > =>
    Effect.gen(function* () {
      const TableSchemaWithSystemFields = SystemFields.extendWithSystemFields(
        tableName,
        tableSchema,
      );

      const encodedDoc =
        self as (typeof TableSchemaWithSystemFields)["Encoded"];

      const decodedDoc = yield* pipe(
        encodedDoc,
        Schema.decodeEffect(TableSchemaWithSystemFields),
        Effect.catchTag(
          "SchemaError",
          (schemaError) =>
            new DocumentDecodeError({
              tableName,
              id: (encodedDoc as { _id: string })._id,
              parseError: schemaError.message,
            }),
        ),
      ) as Effect.Effect<
        DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
        DocumentDecodeError
      >;

      return decodedDoc;
    }),
);

export const encode = Function.dual<
  <
    DataModel_ extends DataModel.AnyWithProps,
    TableName extends DataModel.TableNames<DataModel_>,
  >(
    tableName: TableName,
    tableSchema: TableInfo.TableSchema<
      DataModel.TableInfoWithName_<DataModel_, TableName>
    >,
  ) => (
    self: DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
  ) => Effect.Effect<
    DataModel.TableInfoWithName_<DataModel_, TableName>["encodedDocument"],
    DocumentEncodeError
  >,
  <
    DataModel_ extends DataModel.AnyWithProps,
    TableName extends DataModel.TableNames<DataModel_>,
  >(
    self: DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
    tableName: TableName,
    tableSchema: TableInfo.TableSchema<
      DataModel.TableInfoWithName_<DataModel_, TableName>
    >,
  ) => Effect.Effect<
    DataModel.TableInfoWithName_<DataModel_, TableName>["encodedDocument"],
    DocumentEncodeError
  >
>(
  3,
  <
    DataModel_ extends DataModel.AnyWithProps,
    TableName extends DataModel.TableNames<DataModel_>,
  >(
    self: DataModel.TableInfoWithName_<DataModel_, TableName>["document"],
    tableName: TableName,
    tableSchema: TableInfo.TableSchema<
      DataModel.TableInfoWithName_<DataModel_, TableName>
    >,
  ): Effect.Effect<
    DataModel.TableInfoWithName_<DataModel_, TableName>["encodedDocument"],
    DocumentEncodeError
  > =>
    Effect.gen(function* () {
      type TableSchemaWithSystemFields = SystemFields.ExtendWithSystemFields<
        TableName,
        TableInfo.TableSchema<
          DataModel.TableInfoWithName_<DataModel_, TableName>
        >
      >;

      const decodedDoc = self as TableSchemaWithSystemFields["Type"];

      const encodedDoc = yield* pipe(
        decodedDoc,
        Schema.encodeEffect(tableSchema),
        Effect.catchTag(
          "SchemaError",
          (schemaError) =>
            new DocumentEncodeError({
              tableName,
              id: (decodedDoc as { _id: string })._id,
              parseError: schemaError.message,
            }),
        ),
      ) as Effect.Effect<
        DataModel.TableInfoWithName_<DataModel_, TableName>["encodedDocument"],
        DocumentEncodeError
      >;

      return encodedDoc;
    }),
);

export class DocumentDecodeError extends Schema.TaggedErrorClass<DocumentDecodeError>()(
  "DocumentDecodeError",
  {
    tableName: Schema.String,
    id: Schema.String,
    parseError: Schema.String,
  },
) {
  get message(): string {
    return documentErrorMessage({
      id: this.id,
      tableName: this.tableName,
      message: `could not be decoded:\n\n${this.parseError}`,
    });
  }
}

export class DocumentEncodeError extends Schema.TaggedErrorClass<DocumentEncodeError>()(
  "DocumentEncodeError",
  {
    tableName: Schema.String,
    id: Schema.String,
    parseError: Schema.String,
  },
) {
  get message(): string {
    return documentErrorMessage({
      id: this.id,
      tableName: this.tableName,
      message: `could not be encoded:\n\n${this.parseError}`,
    });
  }
}

export const documentErrorMessage = ({
  id,
  tableName,
  message,
}: {
  id: string;
  tableName: string;
  message: string;
}) => `Document with ID '${id}' in table '${tableName}' ${message}`;
