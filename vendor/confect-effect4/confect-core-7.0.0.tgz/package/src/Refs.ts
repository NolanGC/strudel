import type { Types } from "effect";
import { Array, pipe, Record } from "effect";
import type * as FunctionSpec from "./FunctionSpec";
import * as GroupSpec from "./GroupSpec";
import * as Ref from "./Ref";
import type * as Spec from "./Spec";

export type Refs<
  ConvexSpec extends Spec.AnyWithPropsWithRuntime<"Convex">,
  NodeSpec extends Spec.AnyWithPropsWithRuntime<"Node"> = never,
  Predicate extends Ref.Any = Ref.Any,
> = Types.Simplify<
  OmitEmpty<
    Helper<
      | Spec.Groups<ConvexSpec>
      | (NodeSpec extends never
          ? never
          : GroupSpec.GroupSpec<
              "Node",
              "node",
              never,
              NodeSpec["groups"][keyof NodeSpec["groups"]]
            >),
      Predicate
    >
  >
>;

type GroupRefs<
  Group extends GroupSpec.AnyWithProps,
  Predicate extends Ref.Any,
> = Types.Simplify<
  OmitEmpty<Helper<GroupSpec.Groups<Group>, Predicate>> &
    FilteredFunctions<GroupSpec.Functions<Group>, Predicate>
>;

type OmitEmpty<T> = {
  [K in keyof T as keyof T[K] extends never ? never : K]: T[K];
};

type FunctionSpecMatchesPredicate<
  FunctionSpec_ extends FunctionSpec.AnyWithProps,
  Predicate extends Ref.Any,
> =
  Ref.Ref<
    FunctionSpec.GetRuntimeAndFunctionType<FunctionSpec_>,
    FunctionSpec.GetFunctionVisibility<FunctionSpec_>,
    any,
    any
  > extends Predicate
    ? true
    : false;

type FilteredFunctions<
  FunctionSpecs extends FunctionSpec.AnyWithProps,
  Predicate extends Ref.Any,
> = {
  [Name in FunctionSpec.Name<FunctionSpecs> as FunctionSpec.WithName<
    FunctionSpecs,
    Name
  > extends infer FunctionSpec_ extends FunctionSpec.AnyWithProps
    ? FunctionSpecMatchesPredicate<FunctionSpec_, Predicate> extends true
      ? Name
      : never
    : never]: FunctionSpec.WithName<FunctionSpecs, Name> extends infer F extends
    FunctionSpec.AnyWithProps
    ? Ref.FromFunctionSpec<F>
    : never;
};

type Helper<
  Groups extends GroupSpec.AnyWithProps,
  Predicate extends Ref.Any,
> = {
  [GroupName in GroupSpec.Name<Groups>]: GroupSpec.WithName<
    Groups,
    GroupName
  > extends infer Group extends GroupSpec.AnyWithProps
    ? GroupRefs<Group, Predicate>
    : never;
};

type Any =
  | {
      readonly [key: string]: Any;
    }
  | Ref.Any;

export const make = <
  ConvexSpec extends Spec.AnyWithPropsWithRuntime<"Convex">,
  NodeSpec extends Spec.AnyWithPropsWithRuntime<"Node"> = never,
>(
  convexSpec: ConvexSpec,
  nodeSpec?: NodeSpec,
): {
  public: Refs<ConvexSpec, NodeSpec, Ref.AnyPublic>;
  internal: Refs<ConvexSpec, NodeSpec, Ref.AnyInternal>;
} => {
  const nodeGroup = nodeSpec
    ? Array.reduce(
        Record.values(nodeSpec.groups),
        GroupSpec.makeNode("node"),
        (nodeGroupSpec, group) => nodeGroupSpec.addGroup(group),
      )
    : null;

  const groups = nodeGroup
    ? { ...convexSpec.groups, node: nodeGroup }
    : convexSpec.groups;
  const refs = makeHelper(groups);
  return {
    public: refs as Refs<ConvexSpec, NodeSpec, Ref.AnyPublic>,
    internal: refs as Refs<ConvexSpec, NodeSpec, Ref.AnyInternal>,
  };
};

const makeHelper = (
  groups: Record.ReadonlyRecord<string, GroupSpec.Any>,
  functionNamespace: string | null = null,
): Any =>
  pipe(
    groups as Record.ReadonlyRecord<string, GroupSpec.AnyWithProps>,
    Record.map((group) => {
      const currentFunctionNamespace = functionNamespace
        ? `${functionNamespace}/${group.name}`
        : group.name;

      return Record.union(
        makeHelper(group.groups, currentFunctionNamespace),
        Record.map(group.functions, (function_) =>
          Ref.make(currentFunctionNamespace, function_),
        ),
        (_subGroup, _function) => {
          throw new Error(
            `Group and function at same level have same name ('${Ref.getConvexFunctionName(_function)}')`,
          );
        },
      );
    }),
  );
